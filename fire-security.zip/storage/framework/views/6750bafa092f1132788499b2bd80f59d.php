<?php $__env->startSection('title'); ?>
    Users - Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- PAGE-HEADER -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Users Create</h1>
        </div>
        <div class="ms-auto pageheader-btn">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0);">User</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create</li>
            </ol>
        </div>
    </div>
    <!-- PAGE-HEADER END -->

    <div class=" col-md-12">
        <div class="card">
            <div class="card-header border-bottom">
                <h3 class="card-title">Create New User</h3>
            </div>

            <div class="card-body">
                <p class="text-muted">Fill the form to create a new user.</p>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                    <div class="alert alert-danger mb-3">
                        <ul class="mb-0">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </ul>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <form class="form-horizontal" method="POST" action="<?php echo e(route('users.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <!-- Name -->
                    <div class="row mb-4">
                        <label for="name" class="col-md-3 form-label">Name</label>
                        <div class="col-md-9">
                            <input
                                type="text" id="name" name="name" class="form-control" placeholder="Enter full name" value="<?php echo e(old('name')); ?>" required>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="row mb-4">
                        <label for="email" class="col-md-3 form-label">Email</label>
                        <div class="col-md-9">
                            <input type="email" id="email" name="email" class="form-control" placeholder="Enter email" value="<?php echo e(old('email')); ?>" required>
                        </div>
                    </div>

                    <!-- Password -->
                    <div class="row mb-4">
                        <label for="password" class="col-md-3 form-label">Password</label>
                        <div class="col-md-9">
                            <input type="password" id="password" name="password" class="form-control" placeholder="Enter password" required>
                        </div>
                    </div>

                    <!-- Confirm Password -->
                    <div class="row mb-4">
                        <label for="password_confirmation" class="col-md-3 form-label">Confirm Password</label>
                        <div class="col-md-9">
                            <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" placeholder="Confirm password" required>
                        </div>
                    </div>

                    <!-- Submit -->
                    <div class="text-end">
                        <button type="submit" class="btn btn-primary">Create User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shakh\Herd\abdilahi\resources\views/backend/layouts/users/create.blade.php ENDPATH**/ ?>